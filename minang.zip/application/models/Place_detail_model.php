<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Place_detail_model extends CRUD_Model {
	protected $table_name = "place_detail";
	protected $primary_key = "place_detail_id";
}