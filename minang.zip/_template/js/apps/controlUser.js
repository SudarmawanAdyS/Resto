angular.module('myApp')
.controller('UserController', function($scope){
	$scope.title_panel = "Test Belajar";
});
