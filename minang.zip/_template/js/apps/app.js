angular.module('myApp', ['ui.router']);
var API = "http://localhost/fun/funapi/public/";
