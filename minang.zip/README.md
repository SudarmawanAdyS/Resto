# Minang #

Sistem reservasi restoran minang.

### Todo List ###

1. CRUD Admin
2. CRUD Member
3. Login
4. Logout
5. Register + Profile
6. Crud Denah
7. Crud Meja
8. View Denah
9. Crud Makanan
10. Crud Minuman 
11. View Makanan dan Minuman
12. Setting
13. Reservasi  
&emsp;&emsp; Pesan menu  
&emsp;&emsp; edit jumlah  
&emsp;&emsp; hapus pesnanan  
&emsp;&emsp; pesan tempat  
&emsp;&emsp; hapus tempat  
&emsp;&emsp; ubah jadwal  
&emsp;&emsp; batal reservasi  
&emsp;&emsp; dibatal sistem  
&emsp;&emsp; bayar reservasi  
&emsp;&emsp; Cetak bukti  
14. List Reservasi
15. Pembayaran
16. List Pembayaran  
&emsp;&emsp; Edit Status  
17. Laporan

### Cara Install ###

1. Berdoa hehe
2. Copy project ke server
3. Create database minang_db 
4. Import database minang_db.sql
5. Setting config database jika diperlukan
6. Setting htaccess sesuaikan nama folder
